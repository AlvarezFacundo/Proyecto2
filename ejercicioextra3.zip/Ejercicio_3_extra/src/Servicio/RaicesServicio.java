/*
• Método getDiscriminante(): devuelve el valor del discriminante (double). El
discriminante tiene la siguiente formula: (b^2)-4*a*c
• Método tieneRaices(): devuelve un booleano indicando si tiene dos soluciones, para
que esto ocurra, el discriminante debe ser mayor o igual que 0.
• Método tieneRaiz(): devuelve un booleano indicando si tiene una única solución, para
que esto ocurra, el discriminante debe ser igual que 0.
• Método obtenerRaices(): llama a tieneRaíces() y si devolvió́true, imprime las 2 posibles
soluciones.
• Método obtenerRaiz(): llama a tieneRaiz() y si devolvió́true imprime una única raíz. Es
en el caso en que se tenga una única solución posible.
• Método calcular(): esté método llamará tieneRaices() y a tieneRaíz(), y mostrará por
pantalla las posibles soluciones que tiene nuestra ecuación con los métodos
obtenerRaices() o obtenerRaiz(), según lo que devuelvan nuestros métodos y en caso
de no existir solución, se mostrará un mensaje.
Nota: Formula ecuación 2o grado: (-b±√((b^2)-(4*a*c)))/(2*a) Solo varia el signo delante de -b
 */
package Servicio;

import Entidad.Raices;
import java.util.Scanner;

public class RaicesServicio {

    Scanner leer = new Scanner(System.in);

    public Raices Iniciar() {
        Raices r = new Raices();
        System.out.println("ingrese el coeficiente A : ");
        r.setA(leer.nextDouble());
        System.out.println("ingrese el coeficiente B : ");
        r.setB(leer.nextDouble());
        System.out.println("ingrese el coeficiente C : ");
        r.setC(leer.nextDouble());
        return r;
    }

    public double getDiscriminante(Raices r) {
        double discriminante;
        discriminante = (Math.pow(r.getB(), 2)) - (4 * r.getA() * r.getC());
        return discriminante;
    }//(b^2)-4*a*c

    public boolean tieneRaices(Raices r) {

        return getDiscriminante(r) > 0; // devuelve true  or false
    }//fin riene raices

    public boolean tieneRaiz(Raices r) {

        return getDiscriminante(r) == 0; // devuelve true  or false
    }//fin riene raices

    public void obtenerRaices(Raices r) {
        if (tieneRaices(r)) {
            double r1 = (-r.getB() + Math.sqrt((Math.pow(r.getB(), 2)) - (4 * r.getA() * r.getC())) / 2 * r.getA());
            double r2 = (-r.getB() - Math.sqrt((Math.pow(r.getB(), 2)) - (4 * r.getA() * r.getC())) / 2 * r.getA());
            System.out.println("primer raiz " + r1);
            System.out.println("segunda raiz " + r2);
        }
    }

    public void obtenerRaiz(Raices r) {
        if (tieneRaiz(r)) {
            double r1 = (-r.getB() + Math.sqrt((Math.pow(r.getB(), 2)) - (4 * r.getA() * r.getC())) / 2 * r.getA());
            System.out.println("su unica raiz " + r1);
        }
    }

    public void calcular(Raices r) {
        if (tieneRaices(r)) {
            obtenerRaices(r);

        } else if (tieneRaiz(r)) {
    obtenerRaiz(r);

        } else {
            System.out.println("no tiene solucion en los reales");
        }
    }

}//fin clase raicesservicio
